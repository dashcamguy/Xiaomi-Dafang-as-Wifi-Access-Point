#!/bin/sh

. /system/sdcard/scripts/common_functions.sh

night_mode $1
