To convert audio: fmpeg -i IN.wav -acodec pcm_s16le -ar 8000 -ac 1 OUT.wav
