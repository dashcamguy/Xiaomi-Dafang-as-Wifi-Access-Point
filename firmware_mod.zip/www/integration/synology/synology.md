## Integration in the Synology Surveillance Station

Select "user defined camera" with h264, Port 8554 use /unicast as path and leave user + pass empty in the Surveillance Station settings.

![settings](https://user-images.githubusercontent.com/33186930/36000679-fc39625c-0d23-11e8-9bd8-e944d44af01c.png)

Then switch the transport protocol from auto to TCP. Some people also had success with UDP or disabling the audio.

![settings2](https://user-images.githubusercontent.com/927834/37605071-b6c0659e-2b92-11e8-9be4-a674801761a3.JPG)
