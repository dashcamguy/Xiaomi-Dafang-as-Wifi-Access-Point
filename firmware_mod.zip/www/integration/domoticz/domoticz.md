## Xiaomi Dafang Integration in Domoticz

To control the camera in Domoticz one can create four virtual switches with a script action as on command.
Set a off delay at 1 sec
And as http:// script:

http://[ip_of_camera]/cgi-bin/action.cgi?cmd=motor_right

http://[ip_of_camera]/cgi-bin/action.cgi?cmd=motor_left

http://[ip_of_camera]/cgi-bin/action.cgi?cmd=motor_up

http://[ip_of_camera]/cgi-bin/action.cgi?cmd=motor_down

For more information please see the [original source](https://gadget-freakz.com/2018/03/xiaomi-1080p-xiaofang-camera-review/).
