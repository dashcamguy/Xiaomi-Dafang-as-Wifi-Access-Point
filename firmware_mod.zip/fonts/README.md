## Fonts folder
NotoMono-Regular.ttf and NotoSans-Regular.ttf are mandatory
Some fonts does not be read (to be tested)
Too high size maybe not work (bigger than 70 pixels)


